import statistics

numeros = [8, 10, 10, 10, 6, 7, 8]

mediana = statistics.median(numeros)

print(f"La mediana es: {mediana}")