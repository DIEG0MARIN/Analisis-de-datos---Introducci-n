import statistics

numeros = [1, 2, 10, 6, 4, 4, 6, 3, 1, 4]
mediana = statistics.median(numeros)

print(f"La mediana es: {mediana}")

