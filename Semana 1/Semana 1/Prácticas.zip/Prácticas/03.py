import statistics

numeros = [8, 10, 8, 5, 4, 7, 5, 10, 8]

moda = statistics.mode(numeros)

print(f"La moda es: {moda}")